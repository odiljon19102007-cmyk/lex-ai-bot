import React, { useState } from 'react';
import { 
  FileText, Download, Copy, Check, Sparkles, 
  ChevronRight, RefreshCw, Edit3, ArrowLeft, ShieldCheck
} from 'lucide-react';
import { useTelegram } from './TelegramContext';
import { DOCUMENT_TEMPLATES } from '../../data/telegramLegalPlatform';

export const DocumentDraftingView: React.FC = () => {
  const { theme, haptic, language } = useTelegram();
  const isDark = theme === 'dark';

  const [selectedDocId, setSelectedDocId] = useState<string>('doc_davo_qarz');
  const [applicantName, setApplicantName] = useState('Aliyev Vali Karimovich');
  const [applicantAddress, setApplicantAddress] = useState('Toshkent sh., Chilonzor tumani, 9-mavze');
  const [applicantPhone, setApplicantPhone] = useState('+998 90 123 45 67');
  const [respondentName, setRespondentName] = useState('Karimov Jamshid Shavkatovich');
  const [disputeAmount, setDisputeAmount] = useState('15 000 000');
  const [isEditing, setIsEditing] = useState(false);
  const [customText, setCustomText] = useState('');
  const [copied, setCopied] = useState(false);

  const selectedTemplate = DOCUMENT_TEMPLATES.find((t) => t.id === selectedDocId) || DOCUMENT_TEMPLATES[0];

  const generateDocContent = () => {
    let base = selectedTemplate.sampleText;
    base = base.replace(/Aliyev Vali Karimovich/g, applicantName);
    base = base.replace(/Toshkent sh., Chilonzor tumani, 9-mavze/g, applicantAddress);
    base = base.replace(/\+998 90 123 45 67/g, applicantPhone);
    base = base.replace(/Karimov Jamshid Shavkatovich/g, respondentName);
    base = base.replace(/15 000 000/g, disputeAmount);
    return base;
  };

  const currentContent = isEditing ? customText : generateDocContent();

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    haptic('selection');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    haptic('medium');
    const blob = new Blob([currentContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${selectedTemplate.title.replace(/\s+/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className={`p-5 rounded-3xl border ${
        isDark ? 'bg-gradient-to-r from-[#0c1429] to-[#111e3d] border-indigo-900/50 text-white' : 'bg-white border-slate-200 text-slate-900'
      }`}>
        <div className="flex items-center space-x-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-700 flex items-center justify-center text-white font-bold shadow-md">
            <FileText className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold tracking-tight">
              {language === 'ru' ? 'Подготовка документов' : 'Hujjat Tayyorlash'}
            </h2>
            <p className="text-xs text-slate-400">
              Sud, MIB, ish beruvchi va IIB uchun yuridik kuchga ega arizalar
            </p>
          </div>
        </div>

        {/* Template Selectors */}
        <div className="mt-4 flex gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          {DOCUMENT_TEMPLATES.map((doc) => (
            <button
              key={doc.id}
              onClick={() => {
                haptic('selection');
                setSelectedDocId(doc.id);
                setIsEditing(false);
              }}
              className={`px-3 py-2 rounded-xl font-medium shrink-0 transition flex items-center gap-1.5 cursor-pointer ${
                selectedDocId === doc.id
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                  : isDark
                  ? 'bg-slate-800 text-slate-300 hover:text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>{doc.icon}</span>
              <span>{doc.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Form Fields */}
      <div className={`p-5 rounded-3xl border space-y-4 ${
        isDark ? 'bg-[#0f172a] border-indigo-900/40 text-white' : 'bg-white border-slate-200 text-slate-900'
      }`}>
        <h3 className="font-bold text-sm text-amber-400 flex items-center gap-2">
          <Edit3 className="w-4 h-4" />
          <span>Hujjat ma'lumotlarini to'ldiring:</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">Arizachi (F.I.SH):</label>
            <input
              type="text"
              value={applicantName}
              onChange={(e) => setApplicantName(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl border focus:outline-none ${
                isDark ? 'bg-[#080e1e] text-white border-slate-800' : 'bg-slate-50 text-slate-900 border-slate-300'
              }`}
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Yashash manzili:</label>
            <input
              type="text"
              value={applicantAddress}
              onChange={(e) => setApplicantAddress(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl border focus:outline-none ${
                isDark ? 'bg-[#080e1e] text-white border-slate-800' : 'bg-slate-50 text-slate-900 border-slate-300'
              }`}
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Telefon raqami:</label>
            <input
              type="text"
              value={applicantPhone}
              onChange={(e) => setApplicantPhone(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl border focus:outline-none ${
                isDark ? 'bg-[#080e1e] text-white border-slate-800' : 'bg-slate-50 text-slate-900 border-slate-300'
              }`}
            />
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Javobgar / Qarzdor / Tashkilot:</label>
            <input
              type="text"
              value={respondentName}
              onChange={(e) => setRespondentName(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl border focus:outline-none ${
                isDark ? 'bg-[#080e1e] text-white border-slate-800' : 'bg-slate-50 text-slate-900 border-slate-300'
              }`}
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-slate-400 mb-1">Da'vo summasi / Talab miqdori (so'm):</label>
            <input
              type="text"
              value={disputeAmount}
              onChange={(e) => setDisputeAmount(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl border focus:outline-none ${
                isDark ? 'bg-[#080e1e] text-white border-slate-800' : 'bg-slate-50 text-slate-900 border-slate-300'
              }`}
            />
          </div>
        </div>

        {/* Document Preview & Actions */}
        <div className="pt-2">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Hujjatning rasmiy matni (Ko'rinishi):
            </span>
            <button
              onClick={() => {
                if (!isEditing) setCustomText(generateDocContent());
                setIsEditing(!isEditing);
              }}
              className="text-xs text-amber-400 hover:text-amber-300 font-semibold cursor-pointer"
            >
              {isEditing ? "Ko'rinish rejimiga qaytish" : "Matnni tahrirlash ✏️"}
            </button>
          </div>

          {isEditing ? (
            <textarea
              rows={12}
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              className={`w-full p-4 rounded-2xl border text-xs sm:text-sm font-mono leading-relaxed focus:outline-none ${
                isDark ? 'bg-[#080e1e] text-white border-slate-800' : 'bg-slate-50 text-slate-900 border-slate-300'
              }`}
            />
          ) : (
            <div className={`p-4 rounded-2xl border text-xs sm:text-sm font-mono leading-relaxed whitespace-pre-wrap max-h-96 overflow-y-auto ${
              isDark ? 'bg-[#080e1e] text-slate-200 border-slate-800' : 'bg-slate-50 text-slate-800 border-slate-200'
            }`}>
              {generateDocContent()}
            </div>
          )}

          <div className="mt-4 flex flex-col sm:flex-row items-center gap-2">
            <button
              onClick={handleCopy}
              className="w-full sm:flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs flex items-center justify-center gap-2 border border-slate-700 transition cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Nusxalandi!' : 'Matnni nusxalash'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="w-full sm:flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Fayl sifatida yuklab olish (.txt)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
