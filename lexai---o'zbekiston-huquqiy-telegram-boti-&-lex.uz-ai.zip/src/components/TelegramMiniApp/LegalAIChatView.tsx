import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, Sparkles, Copy, Check, ThumbsUp, ThumbsDown, 
  ExternalLink, RotateCcw, ShieldCheck, AlertTriangle, 
  Bookmark, Paperclip, FileText, CornerDownLeft, Info,
  Camera, Mic, MicOff, Image as ImageIcon, X
} from 'lucide-react';
import { useTelegram } from './TelegramContext';
import { ChatMessage } from '../../types';
import { useSpeechRecognition } from '../../hooks/useSpeechRecognition';

interface LegalAIChatViewProps {
  initialQuery?: string;
  onClearInitialQuery?: () => void;
}

export const LegalAIChatView: React.FC<LegalAIChatViewProps> = ({ initialQuery, onClearInitialQuery }) => {
  const { theme, haptic, language } = useTelegram();
  const isDark = theme === 'dark';

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-tma',
      sender: 'bot',
      text: language === 'ru'
        ? `Здравствуйте! Я — юридический ИИ-помощник Huquq Sphere.\n\nЗадайте любой вопрос по действующему законодательству Республики Узбекистан (Lex.uz).\n• Автоматически отфильтрую устаревшие законы\n• Предоставлю точные статьи и официальные ссылки\n• 📷 Можете прикрепить фото документа или теста для распознавания`
        : `Assalomu alaykum! Men Huquq Sphere — O'zbekiston Respublikasi amaldagi qonunchiligi (Lex.uz) bo'yicha maxsus sun'iy intellekt maslahatchisiman.\n\nSavolingizni yozing yoki mikrofon orqali ayting. Shuningdek, 📷 hujjat, jarima, sud qarori yoki test savolining suratini yuklab tahlil qilishingiz mumkin!`,
      timestamp: '10:00',
      suggestedButtons: [
        { text: "💼 Mehnat: sinov muddati", action: "Yangi Mehnat kodeksida sinov muddati qancha?" },
        { text: "💰 Oylik berilmasa", action: "Ish beruvchi ish haqini bermasa nima qilish kerak?" },
        { text: "🚗 Jarima 50% chegirmasi", action: "Yo'l jarimasini 15 kunda to'lasa 50% chegirma beriladimi?" },
        { text: "🛡️ Tuhmat jazosi", action: "Tuhmat qilgan shaxsga nisbatan qanday chora ko'riladi?" },
      ]
    }
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [bookmarkedIds, setBookmarkedIds] = useState<Set<string>>(new Set());
  
  // Image attachment state
  const [attachedImageBase64, setAttachedImageBase64] = useState<string | null>(null);
  const [attachedImagePreview, setAttachedImagePreview] = useState<string | null>(null);
  const [attachedMimeType, setAttachedMimeType] = useState<string>('image/jpeg');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Speech-to-Text
  const { isListening, errorMsg: speechError, toggleListening } = useSpeechRecognition({
    lang: language === 'ru' ? 'ru-RU' : 'uz-UZ',
    onResult: (text) => {
      haptic('success');
      setInput((prev) => (prev ? `${prev} ${text}` : text));
    },
    onError: () => haptic('error'),
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  useEffect(() => {
    if (initialQuery && initialQuery.trim()) {
      handleSend(initialQuery.trim());
      if (onClearInitialQuery) onClearInitialQuery();
    }
  }, [initialQuery]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert("Faqat rasm formatidagi fayllar qabul qilinadi.");
      return;
    }

    setAttachedMimeType(file.type);
    const reader = new FileReader();
    reader.onload = () => {
      const b64 = reader.result as string;
      setAttachedImagePreview(b64);
      setAttachedImageBase64(b64);
      haptic('light');
    };
    reader.readAsDataURL(file);
  };

  const removeAttachedImage = () => {
    setAttachedImagePreview(null);
    setAttachedImageBase64(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    haptic('light');
  };

  const handleSend = async (customQuery?: string) => {
    const q = (customQuery || input).trim();
    if ((!q && !attachedImageBase64) || isLoading) return;

    haptic('medium');
    const isImageAnalysis = !!attachedImageBase64;
    const currentBase64 = attachedImageBase64;
    const currentMime = attachedMimeType;
    const previewUrl = attachedImagePreview;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: isImageAnalysis 
        ? `${q || "Ushbu rasm/hujjatni O'zbekiston qonunchiligi bo'yicha tahlil qiling va yechim bering."}`
        : q,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    removeAttachedImage();
    setIsLoading(true);

    try {
      let data: any;
      if (isImageAnalysis && currentBase64) {
        // Send to vision solve endpoint
        const res = await fetch('/api/legal-ai/vision-solve', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: currentBase64,
            mimeType: currentMime,
            userPrompt: q || undefined,
          }),
        });
        data = await res.json();
      } else {
        const res = await fetch('/api/legal-ai/query', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: q }),
        });
        data = await res.json();
      }

      if (data.success) {
        haptic('light');
        const botMsg: ChatMessage = {
          id: `bot-${Date.now()}`,
          sender: 'bot',
          text: data.answer,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          sources: data.sources || [{ title: "Lex.uz Qonunchilik Bazasida Ko'rish", uri: "https://lex.uz" }],
          lawStatus: data.lawStatus,
          suggestedButtons: [
            { text: "💡 Yana tushuntirish", action: `${q || 'Hujjat'} bo'yicha batafsil amaliy misollar bilan tushuntirib bering` },
            { text: "📝 Hujjat tayyorlash", action: `${q || 'Hujjat'} bo'yicha tegishli ariza yoki da'vo hujjati tayyorlang` },
          ]
        };
        setMessages((prev) => [...prev, botMsg]);
      } else {
        throw new Error(data.error || "Xatolik yuz berdi");
      }
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `bot-${Date.now()}`,
          sender: 'bot',
          text: `⚠️ Kechirasiz, tahlil qilishda xatolik yuz berdi: ${e.message || "Internet aloqasini tekshirib qaytadan urinib ko'ring."}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    haptic('selection');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleBookmark = (id: string) => {
    haptic('selection');
    setBookmarkedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const rateMessage = (id: string, type: 'up' | 'down') => {
    haptic('medium');
    setMessages((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          return { ...m, rating: m.rating === type ? undefined : type };
        }
        return m;
      })
    );
  };

  const resetChat = () => {
    haptic('heavy');
    setMessages([
      {
        id: 'new-start',
        sender: 'bot',
        text: "Suhbat tozalandi. Yangi huquqiy savolingizni yozing:",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      }
    ]);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] min-h-[500px] max-h-[800px]">
      {/* Mini App Chat Header */}
      <div className={`px-4 py-3 border-b flex items-center justify-between shrink-0 rounded-t-2xl ${
        isDark ? 'bg-[#0f172a] border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-bold shadow-md">
            <Sparkles className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className={`font-bold text-sm ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Huquqiy AI Maslahatchi
              </h3>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.5 rounded-full border border-emerald-500/30">
                Lex.uz 2026
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {isLoading ? 'Qonunlar tahlil qilinmoqda...' : 'Faqat amaldagi qonunchilik asosida'}
            </p>
          </div>
        </div>

        <button
          onClick={resetChat}
          className={`p-2 rounded-xl border text-xs font-medium flex items-center gap-1 transition cursor-pointer ${
            isDark 
              ? 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border-slate-700' 
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
          }`}
          title="Yangi suhbat"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Tozalash</span>
        </button>
      </div>

      {/* Messages Stream */}
      <div className={`flex-1 overflow-y-auto p-4 space-y-4 ${
        isDark ? 'bg-[#0b1329]' : 'bg-slate-50'
      }`}>
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          const isBookmarked = bookmarkedIds.has(msg.id);

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} max-w-full`}
            >
              <div
                className={`relative max-w-[90%] sm:max-w-[85%] rounded-2xl px-4 py-3 shadow-sm text-sm leading-relaxed ${
                  isUser
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-br-xs'
                    : isDark
                    ? 'bg-[#131f3b] text-slate-100 rounded-bl-xs border border-indigo-900/40 shadow-md'
                    : 'bg-white text-slate-800 rounded-bl-xs border border-slate-200 shadow-sm'
                }`}
              >
                {/* Status tag */}
                {!isUser && msg.lawStatus && (
                  <div className={`mb-2.5 pb-2 border-b flex items-center justify-between text-xs ${
                    isDark ? 'border-slate-800' : 'border-slate-100'
                  }`}>
                    {msg.lawStatus === 'ESKI_HUJJAT_ANIQLANDI_VA_YANGILANDI' ? (
                      <span className="inline-flex items-center text-amber-400 font-semibold text-[11px]">
                        <AlertTriangle className="w-3.5 h-3.5 mr-1" />
                        Eski qonun aniqlandi va yangilandi
                      </span>
                    ) : (
                      <span className="inline-flex items-center text-emerald-400 font-semibold text-[11px]">
                        <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                        Amaldagi qonunchilik (Lex.uz)
                      </span>
                    )}

                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => toggleBookmark(msg.id)}
                        className={`p-1 rounded transition cursor-pointer ${
                          isBookmarked ? 'text-amber-400' : 'text-slate-400 hover:text-white'
                        }`}
                        title="Saqlash"
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-400' : ''}`} />
                      </button>
                      <button
                        onClick={() => copyText(msg.text, msg.id)}
                        className="text-slate-400 hover:text-white p-1 rounded transition cursor-pointer"
                        title="Nusxalash"
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {/* Formatted body */}
                <div className="whitespace-pre-wrap font-sans break-words space-y-1.5 text-[13px] leading-relaxed">
                  {msg.text.split('\n').map((line, idx) => {
                    const isHeader = line.startsWith('📌') || line.startsWith('📜') || line.startsWith('⚖️') || line.startsWith('💡') || line.startsWith('📋');
                    if (line.includes('━━━')) {
                      return <hr key={idx} className={`my-1 ${isDark ? 'border-slate-800' : 'border-slate-200'}`} />;
                    }
                    return (
                      <p
                        key={idx}
                        className={`${isHeader ? 'font-bold text-amber-300 mt-1' : ''} ${
                          line.startsWith('⚠️') ? 'text-amber-400 font-medium' : ''
                        }`}
                      >
                        {line}
                      </p>
                    );
                  })}
                </div>

                {/* Lex.uz Sources */}
                {!isUser && msg.sources && msg.sources.length > 0 && (
                  <div className={`mt-3 pt-2 border-t ${isDark ? 'border-slate-800' : 'border-slate-100'}`}>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      Rasmiy Manbalar:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.sources.map((src, i) => (
                        <a
                          key={i}
                          href={src.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center text-xs px-2.5 py-1 rounded-lg bg-black/20 hover:bg-black/40 text-amber-300 border border-amber-500/20 font-medium transition cursor-pointer"
                        >
                          <span className="truncate max-w-[200px]">{src.title}</span>
                          <ExternalLink className="w-3 h-3 ml-1 opacity-70" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Rating and Timestamp Footer */}
                <div className={`flex items-center justify-between mt-2 pt-1 border-t text-[10px] ${
                  isDark ? 'border-slate-800/60 text-slate-400' : 'border-slate-100 text-slate-500'
                }`}>
                  {!isUser ? (
                    <div className="flex items-center space-x-1.5">
                      <span className="text-[10px] text-slate-400">Baholash:</span>
                      <button
                        onClick={() => rateMessage(msg.id, 'up')}
                        className={`p-1 rounded-md transition flex items-center gap-1 cursor-pointer ${
                          msg.rating === 'up'
                            ? 'bg-emerald-500/20 text-emerald-400 ring-1 ring-emerald-500/50'
                            : 'text-slate-400 hover:text-emerald-400'
                        }`}
                        title="Foydali (Thumbs Up)"
                      >
                        <ThumbsUp className={`w-3.5 h-3.5 ${msg.rating === 'up' ? 'fill-emerald-400' : ''}`} />
                        {msg.rating === 'up' && <span className="text-[9px] font-semibold text-emerald-400">To'g'ri</span>}
                      </button>
                      <button
                        onClick={() => rateMessage(msg.id, 'down')}
                        className={`p-1 rounded-md transition flex items-center gap-1 cursor-pointer ${
                          msg.rating === 'down'
                            ? 'bg-rose-500/20 text-rose-400 ring-1 ring-rose-500/50'
                            : 'text-slate-400 hover:text-rose-400'
                        }`}
                        title="Noto'g'ri (Thumbs Down)"
                      >
                        <ThumbsDown className={`w-3.5 h-3.5 ${msg.rating === 'down' ? 'fill-rose-400' : ''}`} />
                        {msg.rating === 'down' && <span className="text-[9px] font-semibold text-rose-400">Qayta ko'rish</span>}
                      </button>
                    </div>
                  ) : <div />}

                  <span>{msg.timestamp}</span>
                </div>
              </div>

              {/* Action buttons */}
              {!isUser && msg.suggestedButtons && msg.suggestedButtons.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5 max-w-[90%] sm:max-w-[85%]">
                  {msg.suggestedButtons.map((btn, btnIdx) => (
                    <button
                      key={btnIdx}
                      onClick={() => {
                        if (btn.action) handleSend(btn.action);
                      }}
                      disabled={isLoading}
                      className={`text-xs px-3 py-1.5 rounded-xl border transition shadow-xs cursor-pointer font-medium ${
                        isDark 
                          ? 'bg-[#121f3d] hover:bg-[#1a2d59] text-slate-200 border-indigo-900/60' 
                          : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-300'
                      }`}
                    >
                      {btn.text}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center space-x-2 text-xs text-amber-400 animate-pulse p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 max-w-[280px]">
            <Sparkles className="w-4 h-4 animate-spin" />
            <span>Lex.uz qonunlari tahlil qilinmoqda...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input box */}
      <div className={`p-3 border-t shrink-0 rounded-b-2xl ${
        isDark ? 'bg-[#0f172a] border-slate-800' : 'bg-white border-slate-200'
      }`}>
        {/* Attached Image Preview */}
        {attachedImagePreview && (
          <div className="mb-2.5 p-2 rounded-xl bg-cyan-950/50 border border-cyan-500/30 flex items-center justify-between text-xs text-cyan-200">
            <div className="flex items-center gap-2">
              <img 
                src={attachedImagePreview} 
                alt="Ilova qilingan rasm" 
                className="w-10 h-10 object-cover rounded-lg border border-cyan-400/40" 
              />
              <div>
                <span className="font-semibold text-cyan-300">📷 Rasm yuklandi (OCR &amp; Yechim)</span>
                <p className="text-[10px] text-slate-400">Yuborish tugmasini bosing yoki savol qo'shing</p>
              </div>
            </div>
            <button
              type="button"
              onClick={removeAttachedImage}
              className="p-1 rounded-md text-slate-400 hover:text-white cursor-pointer"
              title="Bekor qilish"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Voice Listening Banner */}
        {isListening && (
          <div className="mb-2 p-2 rounded-xl bg-rose-950/60 border border-rose-500/40 flex items-center justify-between text-xs text-rose-200">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
              </span>
              <span>🎙️ Tinglanmoqda... Savolingizni ayting</span>
            </div>
            <button
              type="button"
              onClick={() => toggleListening()}
              className="px-2 py-0.5 rounded bg-rose-800 text-[10px] font-bold"
            >
              To'xtatish
            </button>
          </div>
        )}

        {speechError && (
          <p className="mb-1 text-[11px] text-amber-400 px-1">⚠️ {speechError}</p>
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center space-x-1.5"
        >
          {/* Real Photo / Camera Input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageSelect}
            accept="image/*"
            capture="environment"
            className="hidden"
          />

          <button
            type="button"
            onClick={() => {
              haptic('light');
              fileInputRef.current?.click();
            }}
            className={`p-2.5 rounded-xl border transition cursor-pointer ${
              attachedImageBase64 
                ? 'bg-cyan-500 text-slate-950 border-cyan-400' 
                : isDark 
                ? 'bg-slate-800 text-slate-400 hover:text-cyan-400 border-slate-700' 
                : 'bg-slate-100 text-slate-600 hover:text-blue-600 border-slate-300'
            }`}
            title="Hujjat yoki test rasmini yuklash (OCR & Yechim)"
          >
            <Camera className="w-4 h-4" />
          </button>

          {/* Speech-to-Text Microphone Button */}
          <button
            type="button"
            onClick={() => {
              haptic('medium');
              toggleListening();
            }}
            className={`p-2.5 rounded-xl border transition cursor-pointer ${
              isListening
                ? 'bg-rose-600 text-white border-rose-500 animate-pulse'
                : isDark
                ? 'bg-slate-800 text-slate-400 hover:text-amber-400 border-slate-700'
                : 'bg-slate-100 text-slate-600 hover:text-amber-600 border-slate-300'
            }`}
            title={isListening ? "Tinglashni to'xtatish" : "Ovoz orqali savol berish (Speech-to-Text)"}
          >
            {isListening ? <MicOff className="w-4 h-4 text-white" /> : <Mic className="w-4 h-4" />}
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              attachedImageBase64 
                ? "Rasm bo'yicha savolingizni yozing yoki darhol yuboring..." 
                : language === 'ru' 
                ? 'Напишите или продиктуйте вопрос...' 
                : 'Savolingizni yozing yoki mikrofon orqali ayting...'
            }
            disabled={isLoading}
            className={`flex-1 text-xs sm:text-sm px-3.5 py-2.5 rounded-xl border focus:outline-none transition ${
              isDark
                ? 'bg-[#050b18] text-white border-slate-800 focus:border-amber-400 focus:ring-1 focus:ring-amber-400'
                : 'bg-slate-50 text-slate-900 border-slate-300 focus:border-blue-600 focus:ring-1 focus:ring-blue-600'
            }`}
          />

          <button
            type="submit"
            disabled={(!input.trim() && !attachedImageBase64) || isLoading}
            className="p-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold transition disabled:opacity-40 cursor-pointer shadow-md"
            title="Yuborish"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
