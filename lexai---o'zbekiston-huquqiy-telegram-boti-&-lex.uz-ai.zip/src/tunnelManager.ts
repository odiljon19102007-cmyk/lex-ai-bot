import { spawn, ChildProcess } from 'child_process';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let tunnelProcess: ChildProcess | null = null;
let activeTunnelUrl: string | null = null;
let currentPort: number = 3000;
let healthCheckFailures = 0;
let watchdogInterval: any = null;
const listeners: Array<(url: string) => void> = [];

export function getActiveTunnelUrl(): string | null {
  return activeTunnelUrl;
}

export function onTunnelReady(callback: (url: string) => void) {
  if (activeTunnelUrl) {
    try {
      callback(activeTunnelUrl);
    } catch (e) {}
  }
  listeners.push(callback);
}

function notifyListeners(url: string) {
  activeTunnelUrl = url;
  for (const cb of listeners) {
    try {
      cb(url);
    } catch (e) {
      console.error("[Tunnel] Listener error:", e);
    }
  }
}

export function startTunnel(port: number = 3000): Promise<string> {
  currentPort = port;

  return new Promise((resolve, reject) => {
    if (activeTunnelUrl && tunnelProcess && !tunnelProcess.killed) {
      return resolve(activeTunnelUrl);
    }

    const binCandidates = [
      path.resolve(__dirname, '..', 'bin', 'cloudflared'),
      '/tmp/cloudflared',
      'cloudflared'
    ];

    let binPath = binCandidates.find(p => fs.existsSync(p)) || 'cloudflared';

    console.log(`[Tunnel 24/7] Launching cloudflared (${binPath}) on port ${port}...`);

    try {
      tunnelProcess = spawn(binPath, [
        'tunnel',
        '--protocol', 'http2',
        '--url', `http://127.0.0.1:${port}`
      ]);

      let resolved = false;

      const handleData = (chunk: Buffer | string) => {
        const text = chunk.toString();
        const match = text.match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/);
        if (match && !resolved) {
          resolved = true;
          const url = match[0];
          console.log(`[Tunnel 24/7] ✅ Public HTTPS URL active: ${url}`);
          healthCheckFailures = 0;
          notifyListeners(url);
          resolve(url);
        }
      };

      tunnelProcess.stdout?.on('data', handleData);
      tunnelProcess.stderr?.on('data', handleData);

      tunnelProcess.on('error', (err) => {
        console.error("[Tunnel 24/7] Process error:", err);
        if (!resolved) reject(err);
      });

      tunnelProcess.on('exit', (code) => {
        console.warn(`[Tunnel 24/7] Process exited with code ${code}. Auto-reconnecting in 2s...`);
        activeTunnelUrl = null;
        setTimeout(() => {
          if (!activeTunnelUrl) {
            startTunnel(currentPort).catch(() => {});
          }
        }, 2000);
      });

      // Timeout fallback
      setTimeout(() => {
        if (!resolved) {
          if (activeTunnelUrl) {
            resolve(activeTunnelUrl);
          } else {
            reject(new Error("Cloudflare tunnel creation timed out"));
          }
        }
      }, 15000);

      // Start periodic health-check watchdog
      initWatchdog();

    } catch (err) {
      reject(err);
    }
  });
}

function initWatchdog() {
  if (watchdogInterval) return;

  watchdogInterval = setInterval(async () => {
    if (!activeTunnelUrl) {
      console.log("[Tunnel Watchdog] No active URL, triggering restart...");
      startTunnel(currentPort).catch(() => {});
      return;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);
      const res = await fetch(`${activeTunnelUrl}/api/telegram/webapp-url`, {
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (res.ok) {
        healthCheckFailures = 0;
      } else {
        healthCheckFailures++;
      }
    } catch (e) {
      healthCheckFailures++;
      console.warn(`[Tunnel Watchdog] Health check failed (${healthCheckFailures}/2)`);
    }

    if (healthCheckFailures >= 2) {
      console.warn("[Tunnel Watchdog] Tunnel unresponsive, recycling process...");
      healthCheckFailures = 0;
      stopTunnel();
      setTimeout(() => {
        startTunnel(currentPort).catch(() => {});
      }, 1500);
    }
  }, 25000);
}

export function stopTunnel() {
  if (tunnelProcess) {
    try {
      tunnelProcess.kill('SIGTERM');
    } catch (e) {}
    tunnelProcess = null;
  }
  activeTunnelUrl = null;
}
