/**
 * Comprehensive Uzbekistan Legal Knowledge & Problem Solving Engine
 * Covers all legal branches: Mehnat, Oila, Fuqarolik, Jinoyat, Ma'muriy,
 * Yer, Uy-joy, Soliq, Iste'molchilar huquqlari, Sud va Prokuratura.
 */

export interface LegalAdviceResult {
  matched: boolean;
  category: string;
  title: string;
  answer: string;
  lexUrl: string;
}

export function solveUzbekLegalQuestion(rawQuery: string): LegalAdviceResult {
  const q = rawQuery.toLowerCase().trim();

  // 1. Ish haqi / Maosh to'lanmasligi / Oylik
  if (q.includes('ish haqi') || q.includes('ish haq') || q.includes('maosh') || q.includes('oylik') || (q.includes('pul') && (q.includes('ishxona') || q.includes('ish beruvchi')))) {
    return {
      matched: true,
      category: "Mehnat huquqi",
      title: "Oylik ish haqi to'lanmaganda ko'riladigan choralar",
      answer: `⚖️ **Ish beruvchi oylik ish haqini to'lamasa yoki kechiktirsa, nima qilish kerak:**

📌 **1. Qonuniy kafolatlar (Yangi Mehnat kodeksi):**
• **253-modda:** Ish beruvchi xodimga ish haqini har yarim oyda kamida bir marta (oyiga 2 marta) to'lashi shart.
• **333-modda (Majburiy kompensatsiya):** Ish haqi kechiktirilgan har bir kun uchun Markaziy bank qayta moliyalash stavkasi miqdorida majburiy pulli kompensatsiya to'lanishi shart!
• **MJtK 49-moddasi:** Ish haqini bermagan rahbarga BHMning 5 dan 10 baravarigacha jarima solinadi.

📋 **2. NIMA QILISH KERAK (Qadamma-qadam yo'riqnoma):**
1️⃣ **Yozma talabnoma bering:** Ish beruvchiga o'z vaqtida to'lanmagan oylikni to'lash to'g'risida ariza yozing (ariza nusxasiga kirim raqami qo'ydiring).
2️⃣ **Davlat mehnat inspeksiyasiga shikoyat qiling:**
   • 📞 Ishonch telefoni: **1282**
   • 🌐 Sayt: **dmi.mehnat.uz**
3️⃣ **Sudga da'vo arizasi kiriting:** Fuqarolik ishlari bo'yicha tumanlararo sudga ish haqini va har bir kunlik kechiktirish foizini undirish to'g'risida da'vo bering.
⚠️ *IMTIYOZ:* Mehnat nizolari va ish haqini undirish bo'yicha xodimlar **DAVLAT BOJIDAN TO'LIQ OZOD QILINGAN!**

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK (O'RQ-798)
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/6257288`,
      lexUrl: "https://lex.uz/docs/6257288",
    };
  }

  // 2. Tuhmat
  if (q.includes('tuhmat') || q.includes('bo\'hton') || q.includes('tuxmat') || q.includes('yolg\'on ayb')) {
    return {
      matched: true,
      category: "Jinoyat va Ma'muriy huquq",
      title: "Tuhmat qilganlik uchun qonuniy javobgarlik va chora",
      answer: `⚖️ **Tuhmat qilgan shaxsga nisbatan qonuniy choralar:**

📌 **1. Qonunchilikdagi jazo:**
• **MJtK 40-moddasi (Tuhmat):** Bila turib boshqa shaxsni sharmanda qiladigan uydirmalar tarqatish — **BHMning 20 dan 60 baravarigacha jarima** solishga sabab bo‘ladi.
• **Jinoyat kodeksi 139-moddasi:** Agar ma'muriy jazodan keyin takror sodir etilsa yoki Internet orqali tuhmat qilinsa — **jinoiy javobgarlik** (BHMning 200 dan 400 baravarigacha jarima yoki 1 yilgacha ozodlikni cheklash) belgilanadi.

📋 **2. NIMA QILISH KERAK:**
1️⃣ **Dalillarni saqlang:** Skrinshotlar, SMS, audio/video yozuvlar va guvohlar ma'lumotlarini to'plang.
2️⃣ **IIBga ariza yozing:** Yashash joyingizdagi IIB profilaktika inspektoriga yoki tuman prokuraturasiga ariza bilan murojaat qiling.
3️⃣ **Sudda ma'naviy zararni undiring:** Aybdor jazolangach, Fuqarolik sudiga da'vo arizasi kiritib sha'ningiz kamsitilgani uchun moddiy va ma'naviy zararni undirib oling (FK 100 va 1021-moddalar).

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/97664`,
      lexUrl: "https://lex.uz/docs/97664",
    };
  }

  // 3. Haqorat
  if (q.includes('haqorat') || q.includes('so\'k') || q.includes('kamsit')) {
    return {
      matched: true,
      category: "Ma'muriy huquq",
      title: "Haqorat qilganlik uchun jazo va murojaat qilish",
      answer: `⚖️ **Haqorat qilgan shaxsga nisbatan qonuniy choralar:**

📌 **MJtK 41-moddasi (Haqorat qilish):**
Shaxsning sha’ni va qadr-qimmatini qasddan kamsitish — **BHMning 20 baravaridan 40 baravarigacha jarima** solishga sabab bo‘ladi.
• Agar ijtimoiy tarmoqlar orqali amalga oshirilsa yoki takrorlansa: JK 140-modda bo'yicha jinoiy ish qo'zg'atiladi.

📋 **Nima qilish kerak:**
1. Haqoratli so'zlar yozilgan chat yoki ovozli xabarlarni saqlab oling.
2. Hududiy Ichki ishlar bo'limiga ariza bering.
3. Ma'naviy zarar uchun Fuqarolik sudiga murojaat qilish huquqingiz bor.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/97664`,
      lexUrl: "https://lex.uz/docs/97664",
    };
  }

  // 4. Yer nizosi, qo'shnilar, devor, noqonuniy qurilish
  if (q.includes('devor') || q.includes('yer nizo') || q.includes('noqonuniy qur') || q.includes('snos') || q.includes('chegara') || q.includes('qo\'shni') || q.includes('uchastka')) {
    return {
      matched: true,
      category: "Uy-joy va Yer huquqi",
      title: "Qo'shnilar o'rtasida yer va noqonuniy qurilish nizolari",
      answer: `⚖️ **Qo'shni noqonuniy devor yoki imorat qurib olganda nima qilish kerak:**

📌 **1. Qonuniy asos (Fuqarolik kodeksi 212-moddasi):**
• Ruxsatsiz yoki chegarani buzib qurilgan har qanday qurilma — **o'zboshimchalik bilan qurilgan imorat** deb topiladi.
• Bunday qurilmani qurgan shaxs unga mulk huquqini olmaydi va uni **o'z hisobidan buzib tashlashi shart** (FK 212-modda).

📋 **2. NIMA QILISH KERAK:**
1️⃣ **Tuman Davlat kadastrlari palatasi filialiga murojaat qiling:** Mutaxassislar kelib yer chegaralarini o'lchaydi va dalolatnoma (akt) tuzadi.
2️⃣ **Tuman Qurilish bo'limiga ariza bering:** Noqonuniy qurilish yuzasidan tekshiruv o'tkazishni talab qiling.
3️⃣ **Fuqarolik ishlari bo'yicha sudga da'vo arizasi kiriting:** "O'zboshimchalik bilan qurilgan devor/imoratni majburiy buzdirish va yer maydonini avvalgi holatiga keltirish to'g'risida" sudga da'vo qiling.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/111189`,
      lexUrl: "https://lex.uz/docs/111189",
    };
  }

  // 5. Qarz va tilxat
  if (q.includes('qarz') || q.includes('tilxat') || q.includes('pulimni bermayapti') || q.includes('qarzni qaytarmayapti')) {
    return {
      matched: true,
      category: "Fuqarolik huquqi",
      title: "Qarzni sud orqali qaytarib olish",
      answer: `⚖️ **Qarzni qaytarib olish tartibi (Fuqarolik kodeksi 732-736-moddalar):**

📌 **1. Qonuniy asos:**
• Summa BHMning 10 baravaridan oshsa, qarz yozma shaklda (tilxat tarzida) tasdiqlanishi shart (FK 733-modda).
• Tilxat sud uchun rasmiy yozma dalil hisoblanadi.

📋 **2. Qadamma-qadam yo'riqnoma:**
1. Qarz oluvchiga qarzni 30 kun ichida qaytarish haqida rasmiy talabnoma (pretinziya) yuboring.
2. Qarz oluvchi yashaydigan hududdagi **Fuqarolik ishlari bo'yicha tumanlararo sudga** da'vo arizasi bering.
3. Asosiy qarzdan tashqari kechiktirilgan har bir kun uchun foizlarni (FK 327-modda) va davlat bojini undirishni talab qiling.
⚠️ *Eslatma:* Umumiy da'vo muddati — 3 yil.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/111189`,
      lexUrl: "https://lex.uz/docs/111189",
    };
  }

  // 6. Aliment
  if (q.includes('aliment') || (q.includes('bola') && q.includes('ta\'minot'))) {
    return {
      matched: true,
      category: "Oila huquqi",
      title: "Aliment undirish va to'lamaslik oqibatlari",
      answer: `⚖️ **Aliment miqdori va undirish choralari (Oila kodeksi 99-moddasi):**

📌 **1. Aliment miqdorlari:**
• 1 nafar bola uchun — daromadning 1/4 qismi (25%);
• 2 nafar bola uchun — daromadning 1/3 qismi (33.3%);
• 3 va undan ortiq bola uchun — daromadning yarmi (50%).
• Har bir bola uchun eng kam miqdor — MHEKMning 26.5 foizi.

📌 **2. Aliment to'lamay qochganlarga chora:**
• 2 oydan ortiq to'lamasa: **15 sutka ma'muriy qamoq** (MJtK 47-4-modda).
• Takrorlansa: **JK 122-modda bo'yicha 2 yilgacha ozodlikdan mahrum qilish**.
• Chet elga chiqish huquqi taqiqlanadi (MIB orqali).

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/104720`,
      lexUrl: "https://lex.uz/docs/104720",
    };
  }

  // 6.1. Nikoh tuzish shartlari va Nikoh tuzishga monelik qiladigan holatlar
  if (
    q.includes('monelik') ||
    q.includes('to\'siq') ||
    (q.includes('nikoh') && (
      q.includes('shart') ||
      q.includes('mumkin emas') ||
      q.includes('taqiq') ||
      q.includes('qarindosh') ||
      q.includes('yosh') ||
      q.includes('tuzish') ||
      q.includes('oila qurish') ||
      q.includes('tibbiy ko\'rik') ||
      q.includes('16') ||
      q.includes('15') ||
      q.includes('14')
    ))
  ) {
    return {
      matched: true,
      category: "Oila huquqi",
      title: "Nikoh tuzish shartlari va monelik qiladigan holatlar",
      answer: `⚖️ **Nikoh tuzishga monelik qiladigan holatlar (Oila kodeksi 16-moddasi):**

📌 **1. Nikoh tuzish qat'iyan taqiqlangan holatlar:**
O‘zbekiston Respublikasi Oila kodeksining **16-moddasiga** muvofiq, quyidagi shaxslar o‘rtasida nikoh tuzishga **yo‘l qo‘yilmaydi**:
1️⃣ **Kamida bittasi ro‘yxatga olingan boshqa nikohda turgan shaxslar o‘rtasida:**
   • O'zbekistonda ko'pxotinlilik taqiqlangan va Jinoyat kodeksining 126-moddasi bilan jinoiy javobgarlikka tortiladi.
2️⃣ **Nasl-nasab shajarasi bo‘yicha to‘g‘ri tutashgan qarindoshlar o‘rtasida:**
   • Ota-ona va farzandlar, bobo-buvi va nevaralar;
   • Tug‘ishgan hamda o‘gay aka-uka va opa-singillar o‘rtasida nikoh tuzish taqiqlanadi.
3️⃣ **Yaqin yon shajara qarindoshlar o‘rtasida (Taqiq kuchaytirilgan):**
   • Tog‘avachcha, amakivachcha, xolavachcha va ammavachchalar o‘rtasida nikoh tuzish qonunan man etiladi (irsiy kasalliklarning oldini olish).
4️⃣ **Farzandlikka oluvchilar bilan farzandlikka olinganlar o‘rtasida.**
5️⃣ **Ruhiyatining buzilishi sababli:**
   • Ruhiy kasalligi yoki aqli zaifligi sababli sud tomonidan **muomalaga layoqatsiz** deb topilgan shaxslar o‘rtasida.

📋 **2. Nikoh tuzishning asosiy shartlari:**
• **Nikoh yoshi (15-modda):** Erkaklar va ayollar uchun qat'iy **18 yosh**. Uzrli holatlarda (homiladorlik, bola tug'ilishi) tuman/shahar hokimi qarori bilan ko'pi bilan 1 yilga kamaytirilishi mumkin (17 yosh).
• **Ixtiyoriylik (14-modda):** Nikoh tuzish bo'lajak er va xotinning ixtiyoriy o'zaro roziligi asosida amalga oshiriladi. Majburlash taqiqlanadi.
• **Tibbiy ko'rik (17-modda):** FHDYo bo'limiga ariza berilgach, nikohlanuvchilar 5 ta asosiy kasallik bo'yicha davlat tibbiyot muassasalarida **mutlaqo bepul** tibbiy ko'rikdan o'tishlari shart.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
📜 **Hujjat:** O'zbekiston Respublikasining Oila kodeksi
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/104720`,
      lexUrl: "https://lex.uz/docs/104720",
    };
  }

  // 7. Nikohni bekor qilish / Ajrashish
  if (q.includes('ajrash') || q.includes('nikohni bekor') || q.includes('nikohdan ajratish') || q.includes('xotinim bilan ajrash') || q.includes('erim bilan ajrash')) {
    return {
      matched: true,
      category: "Oila huquqi",
      title: "Nikohni bekor qilish tartibi va qoidalari",
      answer: `⚖️ **O'zbekistonda nikohni bekor qilish tartibi (Oila kodeksi 37-44-moddalar):**

📌 **1. Qayerga murojaat qilinadi:**
• **FHDYo (ZAGS) bo'limiga:** Faqat ikkala tomon ham rozi bo'lsa va o'rtada **voyaga yetmagan umumiy farzandlar bo'lmasa** (Oila kodeksi 42-modda).
• **Fuqarolik ishlari bo'yicha sudga:** O'rtada voyaga yetmagan bola bo'lsa yoki er-xotindan biri ajrashishga rozi bo'lmasa (Oila kodeksi 38-41-moddalar).

📋 **2. Sud jarayoni va yarashtirish muddati:**
• Sud er-xotinni yarashtirish uchun **6 oygacha muhlat** tayinlashi mumkin.
• Agar 6 oydan keyin ham oila tiklanmasa, sud nikohni bekor qiladi.
• Sud ajrashish bilan bir vaqtda aliment va bolalarning kim bilan yashashini hamda birgalikdagi mol-mulkni (50/50) hal qiladi.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/104720`,
      lexUrl: "https://lex.uz/docs/104720",
    };
  }

  // 8. Meros
  if (q.includes('meros') || q.includes('vasiyat')) {
    return {
      matched: true,
      category: "Fuqarolik huquqi",
      title: "Merosni qabul qilib olish va taqsimlash",
      answer: `⚖️ **Meros qabul qilish tartibi (Fuqarolik kodeksi 1112-1157-moddalari):**

📌 **ENG ASOSIY QOIDA:**
Merosxo'r shaxs vafot etgan kundan boshlab **6 OY ICHIDA** notarial idoraga merosni qabul qilish haqida ariza berishi shart! Agar bu muddat o'tib ketsa, faqat sud orqali tiklanadi.

📌 **Merosxo'rlar navbati (vasiyatnoma bo'lmasa):**
1-navbat: Bolalar, turmush o'rtoq va ota-onalar (teng ulushda).
2-navbat: Aka-uka, opa-singillar, buva va buvilar.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/111189`,
      lexUrl: "https://lex.uz/docs/111189",
    };
  }

  // 9. Jarimalar va 15 kunlik chegirma
  if (q.includes('jarima') || q.includes('chegirma') || q.includes('radar') || q.includes('yo\'l harakati') || q.includes('ypx') || q.includes('gai')) {
    return {
      matched: true,
      category: "Yo'l harakati va Ma'muriy huquq",
      title: "Jarimalarni to'lashdagi 15 kunlik 50% chegirma",
      answer: `⚖️ **Jarimalarda 15 kunlik chegirma tartibi (MJtK 332-1-moddasi):**

📌 **1. Qonuniy imtiyoz:**
• Jarima solish to'g'risidagi qaror topshirilgan kundan boshlab **15 KUN ICHIDA** jarimaning **50 foizi** to'lansa, qolgan 50 foizidan butunlay ozod qilinadi.
• Sud qarori bo'yicha jarimalarda: 15 kun ichida 70% to'lansa, qolgan 30% bekor bo'ladi.

📌 **2. Qaror ustidan shikoyat qilish:**
• Agar jarima nohaq qo'llanilgan deb hisoblasangiz, qaror nusxasini olgan kundan boshlab **10 kun ichida** yuqori turuvchi organga yoki ma'muriy sudga shikoyat qilishingiz mumkin.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/97664`,
      lexUrl: "https://lex.uz/docs/97664",
    };
  }

  // 10. Guvohnomasiz mashina boshqarish / Prava
  if (q.includes('prava') || q.includes('guvohnoma') || q.includes('haydovchilik') || q.includes('hujjatsiz moshin')) {
    return {
      matched: true,
      category: "Yo'l harakati qoidalari",
      title: "Haydovchilik guvohnomasisiz boshqarish javobgarligi",
      answer: `⚖️ **Haydovchilik guvohnomasisiz avtotransport boshqarganlik uchun jazo:**

📌 **MJtK 135-moddasi:**
• Haydovchilik guvohnomasi yonida bo'lmagan shaxs mashina boshqarsa — **BHMning 1 baravari** miqdorida jarima;
• Umuman haydovchilik huquqi bo'lmagan shaxs boshqarsa — **BHMning 5 baravari** miqdorida jarima;
• Avtotransportni boshqarish huquqidan mahrum etilgan shaxs boshqarsa — **BHMning 10 baravari** miqdorida jarima qo'llaniladi.
• Mashinani boshqarish huquqi bo'lmagan shaxsga boshqarishni topshirish ham **BHMning 5 baravari** jarimaga sabab bo'ladi.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/97664`,
      lexUrl: "https://lex.uz/docs/97664",
    };
  }

  // 11. Iste'molchilar huquqlari (Tovarni qaytarish / Brak)
  if (q.includes('iste\'molchi') || q.includes('brak') || q.includes('tovar') || q.includes('qaytarib olm') || q.includes('nosoz') || q.includes('magazin')) {
    return {
      matched: true,
      category: "Iste'molchilar huquqlari",
      title: "Sifatsiz tovar sotilganda xaridorning huquqlari",
      answer: `⚖️ **Iste'molchilar huquqlarini himoya qilish qoidalari:**

📌 **1. Qonuniy asos ("Iste'molchilarning huquqlarini himoya qilish to'g'risida"gi Qonun):**
• Xaridor nomaqbul sifatli tovar sotilganda o'z xohishiga ko'ra:
  1) Tovarni sifatlisiga almashtirib berishni;
  2) Xarid narxini mutanosib ravishda kamaytirishni;
  3) Shartnomani bekor qilib, **to'langan pulni to'liq qaytarib olishni** talab qilishga haqli!
• Nufuzli tovarlarda: **10 kun ichida** foydalanilmagan tovar almashtirib berilishi shart.

📋 **Qayerga shikoyat qilish kerak:**
• Raqobatni rivojlantirish va iste'molchilar huquqlarini himoya qilish qo'mitasiga (Call-markaz: **1159**).

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/44222`,
      lexUrl: "https://lex.uz/docs/44222",
    };
  }

  // 12. Firibgarlik va karta
  if (q.includes('firibgar') || q.includes('karta') || q.includes('aldab') || q.includes('pul yech') || q.includes('click') || q.includes('payme')) {
    return {
      matched: true,
      category: "Kiberxavfsizlik va Jinoyat huquqi",
      title: "Bank kartasidan pul o'g'irlanganda va firibgarlikda choralar",
      answer: `⚖️ **Bank kartasidan pul o'g'irlanganda yoki firibgarlikda ko'riladigan choralar:**

📌 **1. Qonuniy jazo (JK 168-moddasi):**
• Axborot texnologiyalaridan (plastik karta, ilovalar) foydalanib sodir etilgan firibgarlik — BHMning 100 baravaridan 300 baravarigacha jarima yoki 5 yildan 8 yilgacha ozodlikdan mahrum qilish bilan jazolanadi.

📋 **2. NIMA QILISH KERAK (Birinchi navbatdagi harakatlar):**
1️⃣ **Kartani darhol bloklang:** Bank ilovasi yoki bank Call-markazi orqali kartani to'xtating.
2️⃣ **Bankdan hisob ko'chirmasini oling:** Pul qaysi hisob raqamga yoki qaysi hamyonga o'tkazilganini tasdiqlovchi chekni oling.
3️⃣ **Kiberjinoyatlarga qarshi kurashish bo'limiga ariza bering:**
   • Ichki ishlar vazirligi Kiberxavfsizlik markaziga (📞 **102** yoki **cyber102.uz**) ariza topshiring.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/111453`,
      lexUrl: "https://lex.uz/docs/111453",
    };
  }

  // 13. Pasport / ID-karta
  if (q.includes('pasport') || q.includes('id-karta') || q.includes('id karta') || q.includes('metrika')) {
    return {
      matched: true,
      category: "Ma'muriy tartib-taomillar",
      title: "Pasport yoki ID-karta yo'qolganda / almashtirish tartibi",
      answer: `⚖️ **ID-karta yoki pasport yo'qolganda ko'riladigan choralar:**

📌 **1. Nima qilish kerak:**
1. Darhol istalgan **Davlat xizmatlari markazi (DXM)** yoki tuman IIB Migratsiya va fuqarolikni rasmiylashtirish bo'limiga murojaat qiling yoki **my.gov.uz** portali orqali ariza bering.
2. Yo'qolgan ID-karta o'rniga yangisi **1 ish kuni ichida** rasmiylashtirib beriladi.

📌 **2. Qonuniy jarima (MJtK 223-modda):**
• Pasport yoki ID-kartani qasddan yaroqsizlantirish yoki ehtiyotsizlikdan yo'qotib qo'yish — **BHMning 0.5 baravaridan 3 baravarigacha** jarima solishga sabab bo'ladi.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/97664`,
      lexUrl: "https://lex.uz/docs/97664",
    };
  }

  // 14. Pensiya yoshi va staji
  if (q.includes('pensiya') || q.includes('yoshga doir') || q.includes('nafaqa') || q.includes('staj')) {
    return {
      matched: true,
      category: "Ijtimoiy ta'minot huquqi",
      title: "Pensiya yoshi, zarur staj va tayinlash tartibi",
      answer: `⚖️ **Yoshga doir pensiyaga chiqish tartibi ("Fuqarolarning davlat pensiya ta'minoti to'g'risida"gi Qonun):**

📌 **1. Pensiya yoshi va talab qilinadigan staj:**
• **Erkaklar:** 60 yoshga to'lganda, kamida **25 yillik** ish stajiga ega bo'lganda;
• **Ayollar:** 55 yoshga to'lganda, kamida **20 yillik** ish stajiga ega bo'lganda.
• Kamida 7 yillik staj bo'lsa — to'liqsiz yoshga doir pensiya tayinlanadi.

📋 **Murojaat qilish:**
• Pensiya tayinlash uchun Pensiya jamg'armasi bo'limiga yoki Davlat xizmatlari markaziga (Call-markaz: **1140**) murojaat qilinadi.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/111453`,
      lexUrl: "https://lex.uz/docs/111453",
    };
  }

  // 15. Ijara va ijara shartnomasi
  if (q.includes('ijara') || q.includes('kvartira') || q.includes('arenda')) {
    return {
      matched: true,
      category: "Fuqarolik va Soliq huquqi",
      title: "Turar joy ijarasi va shartnomani soliqda ro'yxatdan o'tkazish",
      answer: `⚖️ **Turar joy ijarasi va uning majburiy qoidalari:**

📌 **1. Majburiy hisobga qo'yish:**
• Ijara shartnomasi tuzilgan kundan boshlab **ijara.soliq.uz** portali orqali soliq organlarida elektron ro'yxatdan o'tkazilishi **SHART**.
• Ijara shartnomasini soliq organida ro'yxatdan o'tkazmaslik — **BHMning 5 baravari** miqdorida jarimaga sabab bo'ladi (MJtK 159-1-modda).
• Talabalarga turar joyini ijaraga bergan fuqarolarning daromadlari jismoniy shaxslar daromad solig'idan **ozod qilinadi**.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/4674902`,
      lexUrl: "https://lex.uz/docs/4674902",
    };
  }

  // 16. Tungi vaqtda shovqin solish
  if (q.includes('shovqin') || q.includes('musiqa') || q.includes('tungi') || q.includes('tinchlik')) {
    return {
      matched: true,
      category: "Ma'muriy huquq",
      title: "Tungi vaqtda shovqin solganlik uchun javobgarlik",
      answer: `⚖️ **Tungi vaqtda fuqarolarning osoyishtaligini buzganlik uchun jazo:**

📌 **MJtK 192-moddasi:**
• Tungi vaqtda — **soat 23:00 dan 06:00 gacha** fuqarolarning osoyishtaligi va tinchini buzish (baland musiqa qo'yish, baqir-chaqir qilish, ta'mirlash shovqini) taqiqlanadi.
• Qoidabuzarga **BHMning 3 dan 1 baravarigacha jarima** solinadi.

📋 **Nima qilish kerak:**
• Tungi shovqin holatida darhol **102** raqami orqali Ichki ishlar bo'limiga xabar bering yoki hudud profilaktika inspektorini chaqiring.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/97664`,
      lexUrl: "https://lex.uz/docs/97664",
    };
  }

  // 17. YATT va Tadbirkorlik
  if (q.includes('yatt') || q.includes('tadbirkor') || q.includes('firma') || q.includes('mchj') || q.includes('biznes')) {
    return {
      matched: true,
      category: "Tadbirkorlik huquqi",
      title: "YATT yoki MChJ ochish va xodim yollash qoidalari",
      answer: `⚖️ **Yakka tartibdagi tadbirkorlik (YATT) va tadbirkorlik ochish tartibi:**

📌 **1. Ro'yxatdan o'tish:**
• Tadbirkor sifatida ro'yxatdan o'tish **birdarcha.uz** yoki **my.gov.uz** portali orqali atigi **30 daqiqada onlayn** amalga oshiriladi.
• YATT faoliyat turiga qarab **5 nafargacha xodimni** mehnat shartnomasi asosida yollash huquqiga ega.

📌 **2. Mehnat munosabati:**
• Yollangan xodimlar bilan tuzilgan shartnomalar soliq organlarining "Yagona milliy mehnat tizimi" (my.mehnat.uz) orqali hisobga qo'yilishi shart.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/4674902`,
      lexUrl: "https://lex.uz/docs/4674902",
    };
  }

  // 18. Dekret va homiladorlik ta'tili
  if (q.includes('dekret') || q.includes('homilador') || q.includes('tug\'ruq') || q.includes('bola parvarish')) {
    return {
      matched: true,
      category: "Mehnat huquqi",
      title: "Homiladorlik va tug'ruq (dekret) ta'tili hamda nafaqalar",
      answer: `⚖️ **Homiladorlik va tug'ruq ta'tili (Yangi Mehnat kodeksi 404-405-moddalari):**

📌 **1. Ta'til muddati va to'lovlar:**
• Ayollarga tuqqanga qadar **70 kalendar kuni** va tuqqanidan keyin **56 kalendar kuni** (tug'ruq qiyin kechgan yoki ikki va undan ortiq bola tug'ilgan hollarda — 70 kun) davomiyligida homiladorlik va tug'ruq ta'tili beriladi.
• Davlat ijtimoiy sug'urtasi bo'yicha **100% miqdorida nafaqa** to'lanadi.
• Bola 2 va 3 yoshga to'lguncha parvarishlash uchun oylik to'lanadigan ta'til olish huquqi kafolatlanadi (405-modda).
• Homilador va bolali ayollarni ish beruvchi tashabbusi bilan ishdan bo'shatish qat'iyan taqiqlanadi (408-modda).

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK (O'RQ-798)
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/6257288`,
      lexUrl: "https://lex.uz/docs/6257288",
    };
  }

  // 19. Urish, jarohat, do'pposlash, janjal
  if (q.includes('urdi') || q.includes('jarohat') || q.includes('do\'ppos') || q.includes('janjal') || q.includes('kaltak')) {
    return {
      matched: true,
      category: "Jinoyat va Ma'muriy huquq",
      title: "Tan jarohati yetkazganlik uchun jinoiy va ma'muriy javobgarlik",
      answer: `⚖️ **Tan jarohati yetkazilganida ko'riladigan choralar:**

📌 **1. Qonuniy javobgarlik:**
• **MJtK 52-moddasi:** Sog'liqning qisqa muddatga yomonlashuviga olib kelmagan qasddan badanga yengil shikast yetkazish — **BHMning 2 dan 4 baravarigacha jarima**;
• **Jinoyat kodeksi 104-109-moddalari:** O'rtacha og'ir yoki og'ir tan jarohati yetkazilsa — **3 yildan 8 yilgacha ozodlikdan mahrum qilish** jazosi belgilanadi.

📋 **Nima qilish kerak:**
1. Zudlik bilan travmatologiya yoki shifoxonaga borib, tan jarohatini qayd ettiring.
2. 102 raqamiga qo'ng'iroq qilib, IIBga ariza bering va Sud-tibbiy ekspertizasi tayinlanishini talab qiling.
3. Aybdordan davolanish xarajatlari va ma'naviy zararni Fuqarolik sudi orqali undiring.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/111453`,
      lexUrl: "https://lex.uz/docs/111453",
    };
  }

  // 20. Davlat idoralari ustidan shikoyat va Sudga murojaat
  if (q.includes('sud') || q.includes('da\'vo') || q.includes('shikoyat') || q.includes('prokuror') || q.includes('adliya')) {
    return {
      matched: true,
      category: "Sud va Huquqiy himoya",
      title: "Sudga murojaat qilish va huquqlarni himoya qilish",
      answer: `⚖️ **O'zbekistonda sudga da'vo arizasi kiritish tartibi:**

📌 **1. Sudlovga tegishlilik:**
• Fuqarolar o'rtasidagi nizolar (qarz, mulk, zarar, aliment, ajrashish) — **Fuqarolik ishlari bo'yicha tumanlararo sudlariga**;
• Ish beruvchi va xodim o'rtasidagi ish haqi va mehnat nizolari — Fuqarolik sudiga (**davlat bojisiz!**);
• Mansabdor shaxslarning noqonuniy qarorlari ustidan — **Ma'muriy sudlarga** beriladi.

📋 **Elektron ariza berish:**
• Sudga arizalarni uydan chiqmasdan **my.sud.uz** portali orqali elektron topshirish mumkin.
• Adliya vazirligining bepul yuridik yordam ishonch telefoni: **1008**.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/4143851`,
      lexUrl: "https://lex.uz/docs/4143851",
    };
  }

  // Intelligent domain-aware legal guidance for all other questions
  const isFamily = q.includes('nikoh') || q.includes('oila') || q.includes('xotin') || q.includes('er') || q.includes('ajrash') || q.includes('farzand') || q.includes('bola') || q.includes('meros') || q.includes('qarindosh');
  const isLabor = q.includes('ish') || q.includes('mehnat') || q.includes('xodim') || q.includes('rahbar') || q.includes('maosh') || q.includes('ta\'til') || q.includes('kompensatsiya');
  const isCriminal = q.includes('jinoyat') || q.includes('o\'g\'ri') || q.includes('firibgar') || q.includes('pora') || q.includes('hujum') || q.includes('jazo') || q.includes('militsiya') || q.includes('iib') || q.includes('tergov');
  const isTraffic = q.includes('mashina') || q.includes('prava') || q.includes('haydovchi') || q.includes('radar') || q.includes('ypx') || q.includes('gai') || q.includes('jarima');
  const isProperty = q.includes('uy') || q.includes('kvartira') || q.includes('yer') || q.includes('kadastr') || q.includes('mulk') || q.includes('notarius') || q.includes('ijara');

  if (isFamily) {
    return {
      matched: false,
      category: "Oila va Fuqarolik huquqi",
      title: "Oila qonunchiligi bo'yicha tahlil va yo'riqnoma",
      answer: `⚖️ **O'zbekiston Respublikasi Oila qonunchiligi bo'yicha huquqiy tahlil:**

📌 **1. Qonuniy asoslar:**
• Mazkur munosabatlar O'zbekiston Respublikasining **Oila kodeksi** hamda **Fuqarolik kodeksi** normalari bilan tartibga solinadi.
• Oilaviy huquqlar shaxsiy daxlsizlik, er va xotinning teng huquqliligi, bolalar manfaatlarini ustuvor himoya qilish tamoyillariga asoslanadi.

📋 **2. NIMA QILISH KERAK (Amaliy harakatlar):**
1️⃣ **Hujjatlarni tayyorlang:** Fuqarolik pasporti/ID-karta, nikoh yoki tug'ilganlik to'g'risidagi guvohnomalar, mulkiy va yozma dalillar.
2️⃣ **Vakolatli organga murojaat qiling:**
   • Ro'yxatdan o'tkazish va rasmiylashtirish: Tuman (shahar) **FHDYo (ZAGS)** bo'limi;
   • Voyaga yetmaganlar manfaati va vasiylik: **Vasiylik va homiylik organi**;
   • Mol-mulk va kelishuvlarni tasdiqlash: **Notarial idoralar**.
3️⃣ **Sud orqali hal etish:** Nizoli holatlarda (ajrashish, aliment, mol-mulkni bo'lish, bolalarning yashash joyi) **Fuqarolik ishlari bo'yicha tumanlararo sudiga** (my.sud.uz orqali) murojaat qilinadi.
• 📞 Huquqiy maslahat uchun Adliya vazirligi ishonch telefoni: **1008**.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
📜 **Hujjat:** O'zbekiston Respublikasining Oila kodeksi
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/104720`,
      lexUrl: "https://lex.uz/docs/104720",
    };
  }

  if (isCriminal) {
    return {
      matched: false,
      category: "Jinoyat va Jinoiy-protsessual huquq",
      title: "Jinoyat qonunchiligi bo'yicha huquqiy xulosa",
      answer: `⚖️ **O'zbekiston Respublikasi Jinoyat qonunchiligi bo'yicha huquqiy ma'lumot:**

📌 **1. Qonuniy asos:**
• Huquqbuzarlik va jinoiy qilmishlar O'zbekiston Respublikasining **Jinoyat kodeksi** va **Ma'muriy javobgarlik to'g'risidagi kodeksi** (MJtK) bilan qat'iy jazolanadi.
• Har bir fuqaro Konstitutsiyaning 26-moddasiga muvofiq, sud hukmi qonuniy kuchga kirmaguncha aybsiz deb hisoblanadi (aybsizlik prezumpsiyasi).

📋 **2. NIMA QILISH KERAK:**
1️⃣ **Dalillarni qayd eting:** Foto/video yozuvlar, yozishmalar, hujjatlar va guvohlar ko'rsatmalarini saqlang.
2️⃣ **Tezkor ariza bilan murojaat qiling:**
   • Ichki ishlar organlariga: 📞 **102** yoki hududiy profilaktika inspektoriga;
   • Mansabdor shaxslarning qonunbuzarligi bo'yicha: **Tuman prokuraturasiga**.
3️⃣ **Yetkazilgan moddiy va ma'naviy zararni undirish:** Jinoyat ishi doirasida fuqaroviy da'vogar sifatida ariza berish yoki fuqarolik sudiga murojaat qilish huquqiga egasiz.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
📜 **Hujjat:** O'zbekiston Respublikasi Jinoyat kodeksi
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/111453`,
      lexUrl: "https://lex.uz/docs/111453",
    };
  }

  if (isTraffic) {
    return {
      matched: false,
      category: "Yo'l harakati va Ma'muriy huquq",
      title: "Yo'l harakati va jarimalar bo'yicha qonuniy tahlil",
      answer: `⚖️ **O'zbekiston Respublikasi Yo'l harakati qonunchiligi bo'yicha ma'lumot:**

📌 **1. Qonuniy asos:**
• Yo'l harakati qoidalari buzilishi bo'yicha javobgarlik **Ma'muriy javobgarlik to'g'risidagi kodeks** (MJtK) bilan tartibga solinadi.
• **332-1-modda (15 kunlik imtiyoz):** Jarima qarori chiqarilgan kundan boshlab 15 kun ichida jarimaning 50%i to'lansa, qolgan qismidan ozod qilinadi.

📋 **2. NIMA QILISH KERAK:**
1️⃣ **Jarimani tekshirish:** **my.gov.uz** portali yoki YHX organlari orqali qaror nusxasini oling.
2️⃣ **Noqonuniy jarima ustidan shikoyat qilish:** Agar jarima noto'g'ri (radar xatosi, boshqa shaxs boshqargan) qo'llanilgan bo'lsa, 10 kun ichida YHX boshqarmasiga yoki Ma'muriy sudga shikoyat qiling.
3️⃣ 📞 YHX xizmati ishonch telefoni: **1102** yoki **102**.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
📜 **Hujjat:** Ma'muriy javobgarlik to'g'risidagi kodeks
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/97664`,
      lexUrl: "https://lex.uz/docs/97664",
    };
  }

  if (isProperty) {
    return {
      matched: false,
      category: "Fuqarolik va Ko'chmas mulk huquqi",
      title: "Ko'chmas mulk va uy-joy masalalari bo'yicha qonuniy tahlil",
      answer: `⚖️ **O'zbekiston Respublikasi Ko'chmas mulk va Uy-joy qonunchiligi:**

📌 **1. Qonuniy kafolatlar:**
• Mulk huquqi daxlsizdir va qonun bilan qo'riqlanadi (Konstitutsiya 65-modda).
• Ko'chmas mulkka oid har qanday oldi-sotdi, hadya, meros va ijara shartnomalari davlat ro'yxatidan o'tkazilishi shart (Fuqarolik kodeksi 111-modda).

📋 **2. NIMA QILISH KERAK:**
1️⃣ **Hujjatlarni tekshiring:** Kadastr pasporti, mulk huquqini tasdiqlovchi order/shartnoma, taqiq (zapret) yo'qligi to'g'risida ma'lumotnoma.
2️⃣ **Davlat xizmatlariga murojaat qiling:**
   • Kadastr va mulkni rasmiylashtirish: **my.gov.uz** yoki Davlat xizmatlari markazi;
   • Notarial tasdiqlash: Tuman notarial idoralari (e-notarius.uz).
3️⃣ **Mulk nizolari bo'yicha:** Nizoli masalalar faqat **Fuqarolik ishlari bo'yicha tumanlararo sudlarida** ko'rib chiqiladi.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
📜 **Hujjat:** O'zbekiston Respublikasi Fuqarolik va Uy-joy kodekslari
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/111189`,
      lexUrl: "https://lex.uz/docs/111189",
    };
  }

  if (isLabor) {
    return {
      matched: false,
      category: "Mehnat huquqi",
      title: "Mehnat munosabatlari bo'yicha qonuniy kafolatlar",
      answer: `⚖️ **O'zbekiston Respublikasi Mehnat qonunchiligi (Yangi Mehnat kodeksi O'RQ-798):**

📌 **1. Asosiy kafolatlar:**
• Xodim va ish beruvchi o'rtasidagi har qanday munosabat amaldagi Yangi Mehnat kodeksi (2023-yil 30-apreldan kuchga kirgan) asosida yuritiladi.
• Har bir xodim qulay mehnat sharoitlarida ishlash, o'z vaqtida oylik maosh olish va qonuniy dam olish huquqiga ega.

📋 **2. NIMA QILISH KERAK:**
1️⃣ **Yozma murojaat qiling:** Ish beruvchi nomiga o'z huquqlaringizni talab qilib rasmiy ariza bering.
2️⃣ **Mehnat inspeksiyasiga shikoyat qiling:**
   • 📞 Ishonch telefoni: **1282**
   • 🌐 Sayt: **dmi.mehnat.uz**
3️⃣ **Sudga murojaat qilish:** Mehnat nizolari bo'yicha xodimlar fuqarolik sudlarida davlat bojidan to'liq ozod etilgan.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK (O'RQ-798)
📜 **Hujjat:** O'zbekiston Respublikasining Yangi Mehnat kodeksi
🔗 **Lex.uz rasmiy havolasi:** https://lex.uz/docs/6257288`,
      lexUrl: "https://lex.uz/docs/6257288",
    };
  }

  // Universal neutral legal solution citing Constitution and Official Legal Portals
  return {
    matched: false,
    category: "O'zbekiston Qonunchiligi",
    title: "Huquqiy tahlil va rasmiy qonunchilik asoslari",
    answer: `⚖️ **O'zbekiston Respublikasining amaldagi qonunchiligi bo'yicha huquqiy tahlil:**

📌 **1. Qonuniy asos va huquqiy kafolat:**
• O'zbekiston Respublikasi yangi tahrirdagi Konstitutsiyasining **55-moddasiga** asosan, har bir fuqaro o'z huquq va erkinliklarini qonunda taqiqlanmagan barcha vositalar bilan himoya qilishga, shu jumladan qonun buzilishi holatlari bo'yicha sudga va vakolatli davlat organlariga murojaat qilishga haqlidir.
• Ushbu masala O'zbekiston Respublikasining tegishli amaldagi kodekslari va qonun hujjatlari doirasida hal etiladi.

📋 **2. NIMA QILISH KERAK (Amaliy qadamlar):**
1️⃣ **Dalillar bazasini to'plang:** Mavzuga oid shartnomalar, arizalar, rasmiy yozishmalar, to'lov kvitansiyalari yoki audio/video ma'lumotlarni saqlang.
2️⃣ **Vakolatli organga murojaat qiling:**
   • Bepul birlamchi yuridik yordam va maslahat: **Adliya vazirligi (📞 1008)**;
   • Fuqarolar huquqlarini sud orqali himoyalash: **my.sud.uz** portali orqali tegishli sudga da'vo arizasi kiriting.
3️⃣ **Lex.uz rasmiy bazasida to'liq o'qish:** O'zbekiston qonunchiligining rasmiy matni bilan Lex.uz portalida tanishing.

🟢 **Maqomi:** ✅ AMALDAGI QONUNCHILIK
🔗 **Lex.uz rasmiy bazasi:** https://lex.uz/uz/search/natsearch?kind=1&text=${encodeURIComponent(rawQuery)}`,
    lexUrl: `https://lex.uz/uz/search/natsearch?kind=1&text=${encodeURIComponent(rawQuery)}`,
  };
}
